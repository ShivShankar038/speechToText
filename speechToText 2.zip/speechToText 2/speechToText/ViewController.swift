//
//  ViewController.swift
//  speechToText
//
//  Created by Manubhav Sharma on 10/09/2021.
//

import UIKit
import Speech

class ViewController: UIViewController, SFSpeechRecognizerDelegate {
    
    let blueColor = UIColor(red: 1/255, green: 32/255, blue: 114/255, alpha:1.0)

    @IBOutlet weak var headerListView: UIView!
    @IBOutlet weak var actionBtn: UIButton!
    @IBOutlet weak var firstUserBtn: UIButton!
    @IBOutlet weak var secondUserBtn: UIButton!
    @IBOutlet weak var microPhoneBtn: UIButton!
    
    @IBOutlet weak var bodyView: UIView!
    @IBOutlet weak var firstUserLbl: UITextView!
    @IBOutlet weak var secondUserLbl: UITextView!
    
    
    let audioEngine = AVAudioEngine()
    let speechReconizer : SFSpeechRecognizer? = SFSpeechRecognizer()
    let request = SFSpeechAudioBufferRecognitionRequest()
    var task : SFSpeechRecognitionTask!
    var isStart : Bool = false
    
    private var isUser1 = false
    private var messageStrings = [String]()
    private var fullMessageString = ""
    private var singleMessageString = ""
    
    
    private var speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: "en-US"))
//    public protocol UIAccessibilityReadingContent {
//        func accessibilityAttributedContent(forLineNumber lineNumber: Int) -> NSAttributedString?
//        func accessibilityAttributedPageContent() -> NSAttributedString?
//    }
//    NSAttributedString(string: "Arc de Triomphe", attributes: [.accessibilitySpeechLanguage: “fr-FR”])
    
    private var segments: [SFTranscriptionSegment] = []
    
    var langCode = String()
    var lang: String = "En"
    var fullsTring = String()
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
//        if (firstUserLbl.text == "") && (secondUserLbl.text == "") {
//            self.actionBtn.isEnabled = false
//        }else{
//            self.actionBtn.isEnabled = true
//        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Looks for single or multiple taps.
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboard))
        view.addGestureRecognizer(tap)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillChange(notification:)), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        // Text View style.
        firstUserLbl.layer.cornerRadius = 8
        firstUserLbl.layer.borderWidth = 1
        firstUserLbl.layer.borderColor = blueColor.cgColor
        firstUserLbl.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        firstUserLbl.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
        firstUserLbl.layer.shadowOpacity = 1.0
        firstUserLbl.layer.shadowRadius = 2.0
        firstUserLbl.layer.masksToBounds = false
        firstUserLbl.contentInset = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        
        secondUserLbl.layer.cornerRadius = 8
        secondUserLbl.layer.borderWidth = 1
        secondUserLbl.layer.borderColor = blueColor.cgColor
        secondUserLbl.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        secondUserLbl.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
        secondUserLbl.layer.shadowOpacity = 1.0
        secondUserLbl.layer.shadowRadius = 2.0
        secondUserLbl.layer.masksToBounds = false
        secondUserLbl.contentInset = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
//        Button View Style
        actionBtn.backgroundColor = .systemGray3
        actionBtn.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        actionBtn.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
        actionBtn.layer.shadowOpacity = 1.0
        actionBtn.layer.shadowRadius = 1.0
        actionBtn.layer.masksToBounds = false
        actionBtn.layer.cornerRadius = 8
//        actionBtn.setTitleColor(blueColor, for: .normal)
        
        firstUserBtn.backgroundColor = .systemGray3
        firstUserBtn.layer.cornerRadius = 8
        firstUserBtn.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        firstUserBtn.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
        firstUserBtn.layer.shadowOpacity = 1.0
        firstUserBtn.layer.shadowRadius = 1.0
        firstUserBtn.layer.masksToBounds = false
        
        secondUserBtn.backgroundColor = .systemGray3
        secondUserBtn.layer.cornerRadius = 8
        secondUserBtn.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        secondUserBtn.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
        secondUserBtn.layer.shadowOpacity = 1.0
        secondUserBtn.layer.shadowRadius = 1.0
        secondUserBtn.layer.masksToBounds = false
        
        microPhoneBtn.layer.cornerRadius = 8
        microPhoneBtn.layer.cornerRadius = 8
        microPhoneBtn.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        microPhoneBtn.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
        microPhoneBtn.layer.shadowOpacity = 1.0
        microPhoneBtn.layer.shadowRadius = 1.0
        microPhoneBtn.layer.masksToBounds = false
        self.microPhoneBtn.isEnabled = false
        self.actionBtn.isEnabled = false
        self.firstUserBtn.isEnabled = false
        self.secondUserBtn.isEnabled = false
//        Speech Delegate
        speechRecognizer?.delegate = self
//        Get Language Type
        switch lang {
           case "En"  :
            langCode = "en-US"
            case "Fr"  :
                langCode = "fr-FR"
            case "De"  :
                langCode = "de-DE"
            case "Ru"  :
                langCode = "ru-RU"
            case "It"  :
                langCode = "it-IT"
            case "Pt"  :
                langCode = "pt-PT"
            case "Es"  :
                langCode = "es-ES"
            case "Ja"  :
                langCode = "ja-JP"
            case "Zh"  :
                langCode = "zh-CN"
            case "Br"  :
                langCode = "pt-BR"
            case "Us"  :
                langCode = "en-US"
           default :
            langCode = "hi-IN"
        }
        speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: langCode))
        
        requestPermission()
        
        
        
        
    }
    
    //Keyboard
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if textView == firstUserLbl {
            firstUserLbl.becomeFirstResponder()
        }else if textView == secondUserLbl {
            secondUserLbl.becomeFirstResponder()
        }else{
            self.view.endEditing(true)
        }
        return true
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    @objc func keyboardWillHide() {
        self.view.frame.origin.y = 0
    }
    
    @objc func keyboardWillChange(notification: NSNotification) {
        if ((notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue) != nil {
            if firstUserLbl.isFirstResponder {
                self.view.frame.origin.y = -20
            }else if secondUserLbl.isFirstResponder {
                self.view.frame.origin.y = -200
            }else{
                self.view.frame.origin.y = 0
            }
        }else{
            self.view.endEditing(true)
        }
    }

    func requestPermission()  {
        self.microPhoneBtn.isEnabled = false
        SFSpeechRecognizer.requestAuthorization { (authState) in
            OperationQueue.main.addOperation {
                if authState == .authorized {
                    print("ACCEPTED")
                    self.microPhoneBtn.isEnabled = true
                } else if authState == .denied {
                    self.alertView(message: "User denied the permission")
                } else if authState == .notDetermined {
                    self.alertView(message: "In User phone there is no speech recognization")
                } else if authState == .restricted {
                    self.alertView(message: "User has been restricted for using the speech recognization")
                }
            }
        }
    }

    @IBAction func actionBtnClick(_ sender: Any) {
        if (isStart == !isStart){
            cancelSpeechRecognization()
        }
        self.actionBtn.backgroundColor = blueColor
        self.secondUserBtn.backgroundColor = .systemGray3
        self.firstUserBtn.backgroundColor = .systemGray3
        microPhoneBtn.setImage(UIImage(named: "mute-microPhone.png"), for: UIControl.State.normal)
        self.firstUserBtn.isEnabled = false
        self.secondUserBtn.isEnabled = false
        self.firstUserLbl.isEditable = false
        self.secondUserLbl.isEditable = false
        
        let firstUserLblText = firstUserLbl.text.description
        _ = firstUserLblText.data(using: String.Encoding.utf16)
        let textSet = firstUserLblText.split(separator: " ")
        let fsecondUserLblText = secondUserLbl.text.description
        let textSet2 = fsecondUserLblText.split(separator: " ")
//        print(textSet)
//        print(textSet2)
        let intersectionWord = textSet.filter(textSet2.contains)
        print(intersectionWord)
//        print("Intersection: ", textSet.filter(textSet2.contains))
//        let comonText = UITextView()
//        comonText.text = intersectionWord.joined(separator:" ")
//        print(comonText)
        
    }
    @IBAction func secondUserBtnClick(_ sender: Any) {
        self.singleMessageString = self.fullMessageString
        self.messageStrings.removeAll()
        self.messageStrings.append(self.secondUserLbl.text ?? "Nothing found")
        self.isUser1 = false
        self.secondUserBtn.backgroundColor = blueColor
        self.firstUserBtn.backgroundColor = .systemGray3
    }
    @IBAction func firstUserBtnClick(_ sender: Any) {
        self.singleMessageString = self.fullMessageString
        self.messageStrings.removeAll()
        self.messageStrings.append(self.firstUserLbl.text ?? "Nothing found")
        self.isUser1 = true
        self.secondUserBtn.backgroundColor = .systemGray3
        self.firstUserBtn.backgroundColor = blueColor
    }
    
    @IBAction func microPhoneBtnClick(_ sender: Any) {
        isStart = !isStart
        if isStart {
            self.isUser1 = true
//            self.isUser2 = false
            startSpeechRecognization()
            self.actionBtn.isEnabled = true
            self.firstUserBtn.isEnabled = true
            self.secondUserBtn.isEnabled = true
            self.firstUserBtn.backgroundColor = blueColor
            self.secondUserBtn.backgroundColor = .systemGray3
            microPhoneBtn.setImage(UIImage(named: "microPhone.png"), for: UIControl.State.normal)
            if firstUserLbl.text == "" {
                firstUserLbl.text = "Say something, I'm listening!"
            }
        }else {
            cancelSpeechRecognization()
            self.actionBtn.isEnabled = false
            self.firstUserBtn.isEnabled = false
            self.secondUserBtn.isEnabled = false
            if firstUserLbl.text == "Say something, I'm listening!" {
                firstUserLbl.text = ""
            }
            microPhoneBtn.setImage(UIImage(named: "mute-microPhone.png"), for: UIControl.State.normal)
            self.firstUserBtn.backgroundColor = .systemGray3
            self.secondUserBtn.backgroundColor = .systemGray3
        }
        self.actionBtn.backgroundColor = .systemGray3
    }
    
    
    func startSpeechRecognization() {
        let node = audioEngine.inputNode
        let recordingFormat = node.outputFormat(forBus: 0)
        
        node.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, _) in
            self.request.append(buffer)
        }
        
        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch let error {
            alertView(message: "Error comes here for starting the audio listner =\(error.localizedDescription)")
        }
        
        guard let myRecognization = SFSpeechRecognizer() else {
            self.alertView(message: "Recognization is not allow on your local")
            return
        }
        
        print(myRecognization.isAvailable)
        if !myRecognization.isAvailable {
            self.alertView(message: "Recognization is not free right now, Please try again after some time.")
        }
        
        task = speechReconizer?.recognitionTask(with: request, resultHandler: { (response, error) in
            guard let response = response else {
                if error != nil {
                    self.alertView(message: error.debugDescription)
                }else {
                    self.alertView(message: "Problem in giving the response")
                }
                return
            }
            var message = response.bestTranscription.formattedString
            self.fullMessageString = message
                        
            if self.isUser1 {
                let replaced = message.replacingOccurrences(of: self.singleMessageString, with: "")
                message = (replaced) + " \n"
                
//                For User 1
                var finalString = ""
                for str in self.messageStrings {
                    finalString = "\(finalString)\(str)"
                }
                finalString = "\(finalString)\(message)"
                self.firstUserLbl.text = "\(finalString.capitalized)"
            } else {
                let replaced = message.replacingOccurrences(of: self.singleMessageString, with: "")
                message = (replaced) + " \n"
                
//                For User 2
                var finalString = ""
                for str in self.messageStrings {
                    finalString = "\(finalString)\(str)"
                }
                finalString = "\(finalString)\(message)"
                self.secondUserLbl.text = "\(finalString.capitalized)"
            }
            
//
//            var lastString: String = ""
//            for segment in response.bestTranscription.segments {
//                let indexTo = message.index(message.startIndex, offsetBy: segment.substringRange.location)
//                lastString = String(message[indexTo...])
//            }
//
//            if lastString == "red" {
//                self.bodyView.backgroundColor = .systemRed
//            } else if lastString.elementsEqual("green") {
//                self.bodyView.backgroundColor = .systemGreen
//            } else if lastString.elementsEqual("pink") {
//                self.bodyView.backgroundColor = .systemPink
//            } else if lastString.elementsEqual("blue") {
//                self.bodyView.backgroundColor = .systemBlue
//            } else if lastString.elementsEqual("black") {
//                self.bodyView.backgroundColor = .black
//            }

            
        })
    }
    
    func cancelSpeechRecognization() {
//        isStart = !isStart
        task.finish()
        task.cancel()
        task = nil
        request.endAudio()
        audioEngine.stop()
        if audioEngine.inputNode.numberOfInputs > 0 {
            audioEngine.inputNode.removeTap(onBus: 0)
        }
        
    }


    func alertView(message : String) {
        let controller = UIAlertController.init(title: "Error ocured...!", message: message, preferredStyle: .alert)
        controller.addAction(UIAlertAction(title: "OK", style: .default, handler: { (_) in
            controller.dismiss(animated: true, completion: nil)
        }))
        self.present(controller, animated: true, completion: nil)
    }
    
    
    
}

